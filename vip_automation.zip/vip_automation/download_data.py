from playwright.sync_api import sync_playwright
import os

URL = "https://shushu.ksztone.com/#/tga/ide/17_58995?tab=result&fromPanel=17_6636"
STATE_FILE = "state.json"
DOWNLOAD_DIR = "downloads"
os.makedirs(DOWNLOAD_DIR, exist_ok=True)
DOWNLOAD_FILE = os.path.join(DOWNLOAD_DIR, "data.csv")

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False)

    # 使用已有登录状态，或者新建 context
    if os.path.exists(STATE_FILE):
        context = browser.new_context(storage_state=STATE_FILE)
    else:
        context = browser.new_context()

    page = context.new_page()
    page.goto(URL)

    # 第一次手动登录
    if not os.path.exists(STATE_FILE):
        print("请手动点击 '其他登录图标' 完成登录")
        input("登录完成后按 Enter 保存登录状态...")
        context.storage_state(path=STATE_FILE)
        print("登录状态已保存")

    page.wait_for_timeout(3000)  # 等页面加载

    # 如果需要选择日期，示例：
    # page.click("input[placeholder='请选择日期']")
    # page.click("text=今天")
    # page.wait_for_timeout(500)

    # 下载 CSV
    page.wait_for_selector("text=导出CSV", timeout=30000)
    with page.expect_download() as download_info:
        page.click("text=导出CSV")
    download = download_info.value
    download.save_as(DOWNLOAD_FILE)

    print(f"CSV 下载完成，保存到 {DOWNLOAD_FILE}")

    browser.close()