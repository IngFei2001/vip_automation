import os

# 1️⃣ 下载数据
os.system("python download_data.py")

# 2️⃣ 处理数据
os.system("python process_data.py")

# 3️⃣ 上传到 Drive
os.system("python upload_drive.py")

print("全部完成！")